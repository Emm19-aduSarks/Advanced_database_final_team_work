drop database akfarms;
create database akfarms;
Use akfarms;

CREATE TABLE StaffMember (
  StaffMemberID INT NOT NULL PRIMARY KEY,
  FirstName VARCHAR(50) NOT NULL,
  LastName VARCHAR(50) NOT NULL,
  Address VARCHAR(100) NOT NULL,
  Phone VARCHAR(20) NOT NULL,
  Gender VARCHAR(10) NOT NULL,
  Email VARCHAR(100) NOT NULL UNIQUE,
  BirthDate DATE NOT NULL
);

CREATE TABLE Farm (
  Farm_id INT NOT NULL PRIMARY KEY,
  FarmSize DECIMAL(10,2) NOT NULL,
  NumOfEmployees INT NOT NULL,
  Vaccination VARCHAR(100) NOT NULL,
  Equipment VARCHAR(100) NOT NULL,
  MedRecord VARCHAR(100) NOT NULL
);

CREATE TABLE Farmer (
  FarmerID INT NOT NULL PRIMARY KEY,
  TypeOfFarmer VARCHAR(50) NOT NULL,
  StartDate DATE NOT NULL,
  Bonus DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (FarmerID) REFERENCES StaffMember(StaffMemberID)
);

CREATE TABLE PoultryFarmer (
  PoultryFarmerID INT NOT NULL PRIMARY KEY,
  Allowance DECIMAL(10,2) NOT NULL,
  Commissions DECIMAL(10,2) NOT NULL,
  NumOfBirds INT NOT NULL,
  FOREIGN KEY (PoultryFarmerID) REFERENCES Farmer(FarmerID)
);

CREATE TABLE PoultryFarm (
   PoultryFarmID INT NOT NULL PRIMARY KEY,
   FarmSize DECIMAL(10,2) NOT NULL,
   NumOfBirds INT NOT NULL,
   TypesOfBirds VARCHAR(100) NOT NULL,
   FeedType VARCHAR(100) NOT NULL,
   NumOfEmployees INT NOT NULL,
   Vaccination VARCHAR(100) NOT NULL,
   Equipment VARCHAR(100) NOT NULL,
   MedRecord VARCHAR(100) NOT NULL,
   PoultryFarmerID INT NOT NULL,
   FOREIGN KEY (PoultryFarmerID) REFERENCES PoultryFarmer(PoultryFarmerID)
);


CREATE TABLE CattleFarmer (
  CattleFarmerID INT NOT NULL PRIMARY KEY,
  Allowance DECIMAL(10,2) NOT NULL,
  Commissions DECIMAL(10,2) NOT NULL,
  NumOfCattle INT NOT NULL,
  FOREIGN KEY (CattleFarmerID) REFERENCES Farmer(FarmerID)
);

CREATE TABLE CattleFarm (
  CattleFarmID INT NOT NULL PRIMARY KEY,
  NumOfCattle INT NOT NULL,
  Breed VARCHAR(100) NOT NULL,
  Age INT NOT NULL,
  Gender VARCHAR(10) NOT NULL,
  ProductionRec VARCHAR(100) NOT NULL,
  FeedType VARCHAR(100) NOT NULL,
  Vaccination VARCHAR(100) NOT NULL,
  MedRecord VARCHAR(100) NOT NULL,
  NumOfEmployees INT NOT NULL,
  FOREIGN KEY (CattleFarmID) REFERENCES CattleFarmer(CattleFarmerID)
);

CREATE TABLE CropFarmer (
  CropFarmerID INT NOT NULL PRIMARY KEY,
  Allowance DECIMAL(10,2) NOT NULL,
  Commissions DECIMAL(10,2) NOT NULL,
  NumOfCrops INT NOT NULL,
  FOREIGN KEY (CropFarmerID) REFERENCES Farmer(FarmerID)
);

CREATE TABLE CropFarm (
  CropFarmID INT NOT NULL PRIMARY KEY,
  CropType VARCHAR(100) NOT NULL,
  Acreage DECIMAL(10,2) NOT NULL,
  SoilType VARCHAR(100) NOT NULL,
  FertilizerType VARCHAR(100) NOT NULL,
  Quantity_Fertilizer INT NOT NULL,
  PlantDate DATE NOT NULL,
  HarvestDate DATE NOT NULL,
  Pesticide VARCHAR(100) NOT NULL,
  IrrigationMethod VARCHAR(100) NOT NULL,
  Yield DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (CropFarmID) REFERENCES CropFarmer(CropFarmerID)
);

CREATE TABLE Manager (
  manager_id INT(11) NOT NULL PRIMARY KEY,
  firstname VARCHAR(50) NOT NULL,
  lastname VARCHAR(50) NOT NULL,
  address VARCHAR(100) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  gender ENUM('Male','Female') NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  birthdate DATE NOT NULL,
  manager_start_date DATE NOT NULL,
  bonus DECIMAL(10, 2) NOT NULL
);


CREATE TABLE Customer (
   customer_id INT AUTO_INCREMENT PRIMARY KEY,
   firstname VARCHAR(50) NOT NULL,
   lastname VARCHAR(50) NOT NULL,
   email VARCHAR(100) NOT NULL,
   phone VARCHAR(20) NOT NULL,
   address VARCHAR(255) NOT NULL
);


CREATE TABLE Sales_Accounting (
  sa_id INT(11) NOT NULL PRIMARY KEY,
  firstname VARCHAR(50) NOT NULL,
  lastname VARCHAR(50) NOT NULL,
  address VARCHAR(100) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  gender ENUM('Male', 'Female') NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  birthdate DATE NOT NULL,
  allowance DECIMAL(10, 2) NOT NULL,
  commission DECIMAL(10, 2) NOT NULL
);

CREATE TABLE Farm_Shop (
  shop_id INT(11) NOT NULL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  date DATE NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  description VARCHAR(500) NOT NULL,
  quantity INT(11) NOT NULL,
  farm_id INT(11) NOT NULL,
  FOREIGN KEY (farm_id) REFERENCES Farm(farm_id)
);

CREATE TABLE Farm_Equipment (
  equipment_id INT(11) NOT NULL PRIMARY KEY,
  model VARCHAR(100) NOT NULL,
  year_of_purchase YEAR NOT NULL,
  cost DECIMAL(10, 2) NOT NULL,
  warranty DATE NOT NULL,
  farm_id INT(11) NOT NULL,
  FOREIGN KEY (farm_id) REFERENCES Farm(farm_id)

);


INSERT INTO StaffMember (StaffMemberID, FirstName, LastName, Address, Phone, Gender, Email, BirthDate) VALUES
(1, 'John', 'Doe', '123 Main St, Accra', '+233555123456', 'Male', 'johndoe@example.com', '1980-01-01'),
(2, 'Jane', 'Doe', '456 Second St, Kumasi', '+233555654321', 'Female', 'janedoe@example.com', '1982-02-02'),
(3, 'Kwame', 'Appiah', '789 Third St, Cape Coast', '+233555111222', 'Male', 'kwameappiah@example.com', '1985-03-03'),
(4, 'Ama', 'Boakye', '321 Fourth St, Takoradi', '+233555333444', 'Female', 'amaboakye@example.com', '1990-04-04'),
(5, 'Kofi', 'Mensah', '654 Fifth St, Tamale', '+233555777888', 'Male', 'kofimensah@example.com', '1995-05-05');

INSERT INTO Farm (Farm_id, FarmSize, NumOfEmployees, Vaccination, Equipment, MedRecord) VALUES
(1, 1000.00, 20, 'Avian Influenza, Newcastle Disease', 'Feeders, Waterers, Brooders', 'Daily Medication Record'),
(2, 500.00, 10, 'Bovine Viral Diarrhea, Infectious Bovine Rhinotracheitis', 'Milking Machine, Tractors, Plows', 'Weekly Medication Record'),
(3, 2000.00, 30, 'Mycoplasma Gallisepticum, Fowl Cholera', 'Feed Bins, Water Troughs, Hatchers', 'Monthly Medication Record'),
(4, 1500.00, 25, 'Foot-and-Mouth Disease, Brucellosis', 'Fencing, Hay Bales, Stock Trailers', 'Bi-Weekly Medication Record'),
(5, 3000.00, 40, 'Porcine Reproductive and Respiratory Syndrome, Swine Influenza', 'Heat Lamps, Ventilation Fans, Water Nipples', 'Daily Medication Record');

INSERT INTO Farmer (FarmerID, TypeOfFarmer, StartDate, Bonus) VALUES
(1, 'Poultry Farmer', '2021-01-01', 5000.00),
(2, 'Cattle Farmer', '2020-01-01', 7500.00),
(3, 'Crop Farmer', '2019-01-01', 10000.00),
(4, 'Poultry Farmer', '2021-02-01', 4000.00),
(5, 'Cattle Farmer', '2020-02-01', 6000.00);


INSERT INTO Customer (firstname, lastname, email, phone, address) VALUES
('Kwame', 'Agyei', 'kwameagyei@example.com', '+233-24-555-6789', '12 Kojo Thompson Road, Accra, Ghana'),
('Ama', 'Boateng', 'amaboateng@example.com', '+233-20-123-4567', '34 Adenta-Frafraha Road, Accra, Ghana'),
('Kofi', 'Asare', 'kofiasare@example.com', '+233-27-987-6543', '5 North Legon Road, Accra, Ghana'),
('Akosua', 'Addo', 'akosuaaddo@example.com', '+233-24-777-8888', '123 High Street, Kumasi, Ghana'),
('Yaw', 'Owusu', 'yawowusu@example.com', '+233-27-444-3333', '87 Tetteh Quarshie Circle, Accra, Ghana');

INSERT INTO CattleFarmer (CattleFarmerID, Allowance, Commissions, NumOfCattle)
VALUES
(1, 2000.00, 0.05, 20),
(2, 1500.00, 0.03, 15),
(3, 1800.00, 0.04, 18);

INSERT INTO CattleFarm (CattleFarmID, NumOfCattle, Breed, Age, Gender, ProductionRec, FeedType, Vaccination, MedRecord, NumOfEmployees)
VALUES
(1, 20, 'Holstein Friesian', 2, 'Female', 'Good', 'Grass Hay', 'Bovine Viral Diarrhea (BVD)', 'Available', 3),
(2, 15, 'Hereford', 3, 'Male', 'Excellent', 'Corn Silage', 'Infectious Bovine Rhinotracheitis (IBR)', 'Available', 2),
(3, 18, 'Angus', 2, 'Male', 'Very good', 'Alfalfa Hay', 'Bovine Respiratory Syncytial Virus (BRSV)', 'Available', 4);


INSERT INTO PoultryFarmer (PoultryFarmerID, Allowance, Commissions, NumOfBirds) VALUES
(1, 2000.00, 0.05, 5000),
(4, 1500.00, 0.03, 3000);

SHOW COLUMNS FROM PoultryFarm LIKE 'PoultryFarmerID';

ALTER TABLE PoultryFarm MODIFY COLUMN PoultryFarmerID INT;

-- ALTER TABLE PoultryFarm ADD COLUMN FarmerID INT;

-- ALTER TABLE PoultryFarm ADD COLUMN PoultryFarmerID INT;

-- ALTER TABLE PoultryFarm ADD CONSTRAINT fk_PoultryFarmerID
--    FOREIGN KEY (PoultryFarmerID) REFERENCES PoultryFarmer(PoultryFarmerID);
-- ALTER TABLE PoultryFarm MODIFY COLUMN PoultryFarmerID INT NOT NULL REFERENCES PoultryFarmer(PoultryFarmerID);


SELECT * FROM StaffMember;

 -- Query to display the first name and email address of all staff members who are farmers and started before 2022.
SELECT sm.FirstName, sm.Email 
FROM StaffMember sm 
INNER JOIN Farmer f ON sm.StaffMemberID = f.FarmerID 
WHERE f.StartDate < '2022-01-01';

-- Query to Show the farm_id, farm size, and number of employees for all farms that have more than 5 employees, ordered by farm size in descending order.
SELECT Farm_id, FarmSize, NumOfEmployees 
FROM Farm 
WHERE NumOfEmployees > 5 
ORDER BY FarmSize DESC;

-- Query to display the cattle farm ID, breed, and age of all cattle with age less than 2 years, sorted by breed.

SELECT CattleFarmID, Breed, Age 
FROM CattleFarm 
WHERE Age > 1 
ORDER BY Breed ASC;





SELECT * FROM Customer WHERE phone = '+233-24-555-6789';








SELECT * FROM Customer WHERE email LIKE '%@example.com';

UPDATE Customer SET phone = '+233-20-555-7777' WHERE customer_id = 3;



