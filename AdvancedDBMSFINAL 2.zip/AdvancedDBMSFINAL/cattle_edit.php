<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


require "dbcredentials.php";

// Create connection
$conn = mysqli_connect($hostname, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Get the form data
  $cattlenum = $_POST["cattlenum"];
  $breed= $_POST["breed"];
  $feed_type = $_POST["feed_type"];
  $vaccination = $_POST["vac"];
  $emp_num = $_POST["emp_num"];
  $cattlefarmIdvar = $_POST["cattlefarmID"];

//   echo $cropfarmIdvar;

  // Prepare the SQL statement
  $sql = "UPDATE CattleFarm
  SET NumOfCattle = '$cattlenum', Breed = '$breed', FeedType= '$feed_type', Vaccination = '$vaccination', NumOfEmployees = '$emp_num'
  WHERE CattleFarmID = $cattlefarmIdvar";



  // Execute the SQL statement
  if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
    header("Location: cropfarms.php");
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
}

// Close the database connection
$conn->close();
?>