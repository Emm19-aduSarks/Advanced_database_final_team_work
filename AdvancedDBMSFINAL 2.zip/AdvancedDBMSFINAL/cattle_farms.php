<?php

require "dbcredentials.php";

// Create connection
$conn = mysqli_connect($localhost, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Select data from table
$sql = "SELECT * FROM CattleFarm";
$result = mysqli_query($conn, $sql);
$cows = mysqli_fetch_all($result, MYSQLI_ASSOC);
//var_dump($crops);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Akoma Farms Dashboard</title>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link rel="stylesheet" href="dashboard.css">
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>

</head>

<body>
   <nav>
       <div class="logo-name">
            <div class="logo-image">
                <img src="images/logomain.png" alt="">
            </div>
            <span class="logo_name">Akoma Farms</span>
        </div>
        <div class="menu-items">
        <ul class="nav-links">
            <li><a href="dashboard.php">
                <i class="uil uil-estate"></i>
                <span class="link-name">Dashboard</span>
            </a></li>
            <li><a href="cropfarms.php">
                <i class="uil uil-pagelines"></i>
                <span class="link-name">Crop Farms</span>
            </a></li>
            <li><a href="customers.php">
            <i class="uil uil-user-square"></i>
                <span class="link-name">Customers</span>
            </a></li>
            <li><a href="cattle_farms.php">
                <i class="uil uil-bug"></i>
                <span class="link-name">Cattle Farms</span>
            </a></li>
            <li><a href="poultry_farms.php">
            <i class="uil uil-twitter"></i>
                <span class="link-name">Poultry Farms</span>
            </a></li>
            <li><a href="employees.php">
            <i class="uil uil-user-circle"></i>
                <span class="link-name">Employees</span>
            </a></li>
            <li><a href="product.php">
                <i class="uil uil-shopping-bag"></i>
                <span class="link-name">Sales</span>
            </a></li>
            </ul>
            <ul class="logout-mode">
                <li><a href="index.php">
                <i class="uil uil-signout"></i>
                <span class="link-name">Logout</span>
                <a></li>




                <li class="mode">
                    <a href="#">
                <a>

                <div class="mode-toggle"></div>
                <span class="switch"></span>
                </li>
            </ul>
        </div>
   </nav>

   <section class="dashboard">
       <div class="top">
           
           <!-- <button class="add-farm-btn">+Add Farm</button> -->


           <div class="search-box">
               <i class="uil uil-search"></i>
               <input type="text" placeholder="Search Here...">
            </div>

            <img src="images/user.png">
        </div>

       

    <div class="crops" style="float:left">
        <br>
        <br>
        <br>
        <?php
        foreach($cows as $cow):
        ?>
            <div class="card">
                <img src="images/animal3.jpg" alt="animal 1">
                <div class="card-info">
                    <h2>Cattle Farm 1</h2>
                </div>
                <div class="card-popup">
                    <br>
                    <br>
                    <br>
                
                <p>Number of Cows:<?php echo $cow["NumOfCattle"];?></p>
                <p>Breed: <?php echo $cow["Breed"];?></p>
                <p>Feed Type: <?php echo $cow["CropType"];?></p>
                <p>Vaccination: <?php echo $cow["Vaccination"];?></p>
                <p>Number of Employees: <?php echo $cow["NumOfEmployees"];?></p>
         <button class="edit-btn" id = "edit-btn" data-cattle_farm_ID="<?php echo $cow["CattleFarmID"]?>" onclick="getCattleFarmID(this)">Edit</button>
         <button class="delete-farm-btn">- Delete Farm</button>
         <?php
            endforeach;
        ?>




                    <div id="edit-modal2" class="modal">
                        <div class="modal-content">
                            <span class="close">&times;</span>
                            <h2>Edit Farm Details</h2>
                            <br>
                            <form method="POST" action="cattle_edit.php">
                                <label for="assignedfarmwe">Number of Cattle:</label>
                                <input type="text" id="cattlenum" name="cattlenum">
                                <br>
                                <label for="numbercocks">Breed:</label>
                                <input type="text" id="breed" name="breed">
                                <br>
                                <label for="numberhens">Feed Type:</label>
                                <input type="text" id="feed_type" name="feed_type">
                                <br>
                                <label for="numbereggs">Vaccination:</label>
                                <input type="text" id="vac" name="vac">
                                <br>
                                <label for="kgeat">Number of Employees:</label>
                                <input type="text" id="emp_num" name="emp_num">
                                <input type="hidden" name="cattlefarmID" id="cattlefarmID"> 

                                <input class="sub1mit" type="submit" value="Submit">
                            </form>
                        </div>
                    </div>

                </div>
            </div>

  



            <div class="card">
                <img src="images/animal3.jpg" alt="animal 2">
                <div class="card-info">
                    <h2>Cattle Farm 2</h2>
                </div>
                <div class="card-popup">
                    <br>
                    <br>
                    <br>
          
                    <button class="edit-btn" id="edit-btn">Edit</button>

                    <button class="delete-farm-btn">- Delete Farm</button>

                    <div id="edit-modal" class="modal">
                        <div class="modal-content">
                            <span class="close">&times;</span>
                            <h2>Edit Farm Details</h2>
                            <br>
                            <form>
                                <label for="phosphorus">No. of Carrots Planted:</label>
                                <input type="text" id="planted" name="planted">
                                <br>
                                <label for="phosphorus">No. of Carrots Produced:</label>
                                <input type="text" id="produced" name="produced">
                                <br>
                                <label for="phosphorus">Soil PH Level:</label>
                                <input type="text" id="PH" name="PH">
                                <br>
                                <label for="phosphorus">Phosphorus:</label>
                                <input type="text" id="phosphorus" name="phosphorus">
                                <br>
                                <label for="nitrogen">Nitrogen:</label>
                                <input type="text" id="nitrogen" name="nitrogen">
                                <br>
                                <label for="oxygen">Oxygen:</label>
                                <input type="text" id="oxygen" name="oxygen">
                                <br>
                                <input class="sub1mit" type="submit" value="Submit">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            

       
            
        </div>

	</div>
            





<script>
// Get the modal
var modal = document.getElementById("edit-modal");
var modal2 = document.getElementById("edit-modal2");

// Get the button that opens the modal
const btn = document.querySelectorAll(".edit-btn");
var btn2 = document.getElementById("add-farm-btn");


btn.forEach(button => {
    button.addEventListener('click',() =>{
        modal2.style.display = "block";
    });
});









// Add an event listener to the button
btn.addEventListener("click", function() {
  // Show the modal when the button is clicked
  modal2.style.display = "block";
});

// Add an event listener to close the modal when clicking outside of it
window.addEventListener("click", function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
});

function getCattleFarmID(button){
    var cattleFarmId = button.getAttribute("data-cattle_farm_ID");

    //select hidden input
    const h_input = document.getElementById("cattlefarmID");
    h_input.value = cattleFarmId;
    //alert(cropFarmId);

}





</script>
</section>
    
</body>
</html>
