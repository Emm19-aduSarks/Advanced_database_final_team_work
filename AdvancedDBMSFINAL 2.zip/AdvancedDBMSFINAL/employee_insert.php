<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require "dbcredentials.php";

// Create connection
$conn = mysqli_connect($hostname, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $fname = $_POST["fname"]; 
    $lname= $_POST["lname"];
    $address= $_POST["adress"];	
    $phone= $_POST["phone"];
    $gender= $_POST["gender"];
    $email= $_POST["email"];
    $farm_ass= $_POST["farm_ass"];
    $staffMemberID= $_POST["staffMemberID"];
    	
  

    // Prepare an SQL statement
    $sql = "INSERT INTO StaffMember (StaffMemberID, FirstName, LastName, Address, Phone, Gender, Email, BirthDate) 
    VALUES ('$staffMemberID','$fname','$lname','$address','$phone','$gender','$email','$farm_ass')";
  
  
    // Execute the SQL statement
    if (mysqli_query($conn, $sql)) {
      echo "New record created successfully";
    } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
  }
  
  // Close the database connection
  mysqli_close($conn);
  ?>


?>