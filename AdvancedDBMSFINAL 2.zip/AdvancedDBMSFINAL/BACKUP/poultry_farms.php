<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Akoma Farms Dashboard</title>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link rel="stylesheet" href="dashboard.css">
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>

</head>

<body>
   <nav>
       <div class="logo-name">
            <div class="logo-image">
                <img src="images/logomain.png" alt="">
            </div>
            <span class="logo_name">Akoma Farms</span>
        </div>
        <div class="menu-items">
        <ul class="nav-links">
            <li><a href="dashboard.php">
                <i class="uil uil-estate"></i>
                <span class="link-name">Dashboard</span>
            </a></li>
            <li><a href="cropfarms.php">
                <i class="uil uil-pagelines"></i>
                <span class="link-name">Crop Farms</span>
            </a></li>
            <li><a href="customers.php">
            <i class="uil uil-user-square"></i>
                <span class="link-name">Customers</span>
            </a></li>
            <li><a href="cattle_farms.php">
                <i class="uil uil-bug"></i>
                <span class="link-name">Cattle Farms</span>
            </a></li>
            <li><a href="poultry_farms.php">
            <i class="uil uil-twitter"></i>
                <span class="link-name">Poultry Farms</span>
            </a></li>
            <li><a href="employees.php">
            <i class="uil uil-user-circle"></i>
                <span class="link-name">Employees</span>
            </a></li>
            <li><a href="product.php">
                <i class="uil uil-shopping-bag"></i>
                <span class="link-name">Sales</span>
            </a></li>
            </ul>

            <ul class="logout-mode">
                <li><a href="index.php">
                <i class="uil uil-signout"></i>
                <span class="link-name">Logout</span>
                <a></li>




                <li class="mode">
                    <a href="#">
                <a>

                <div class="mode-toggle"></div>
                <span class="switch"></span>
                </li>
            </ul>
        </div>
   </nav>

   <section class="dashboard">
       <div class="top">
           
           <button class="add-farm-btn">+Add Farm</button>


           <div class="search-box">
               <i class="uil uil-search"></i>
               <input type="text" placeholder="Search Here...">
            </div>

            <img src="images/user.png">
        </div>

       

    <div class="crops" style="float:left">
        <br>
        <br>
        <br>
            <div class="card">
                <img src="images/animal1.jpg" alt="animal 1">
                <div class="card-info">
                    <h2>Chicken Farm 1</h2>
                </div>
                <div class="card-popup">
                    <br>
                    <br>
                    <br>
                <p>Assigned Farmer: Mr. Asamoah</p>
                <p>100 cockrels</p>
                        <p>100 hens</p>
                        <p>50 eggs</p>
                        <p>45 kg's of meat</p>
                    <button class="edit-btn" id = "edit-btn">Edit</button>
                    <button class="delete-farm-btn">- Delete Farm</button>




                    <div id="edit-modal" class="modal">
                        <div class="modal-content">
                            <span class="close">&times;</span>
                            <h2>Edit Farm Details</h2>
                            <br>
                            <form>
                                <label for="assignedfarmwe">Assigned Farmer:</label>
                                <input type="text" id="planted" name="planted">
                                <br>
                                <label for="numbercocks">No. of cockrels:</label>
                                <input type="text" id="planted" name="planted">
                                <br>
                                <label for="numberhens">No. of Hens:</label>
                                <input type="text" id="produced" name="produced">
                                <br>
                                <label for="numbereggs">No. of eggs:</label>
                                <input type="text" id="PH" name="PH">
                                <br>
                                <label for="kgeat">Kg's of meat:</label>
                                <input type="text" id="phosphorus" name="phosphorus">
                
                                <input class="sub1mit" type="submit" value="Submit">
                            </form>
                        </div>
                    </div>

                </div>
            </div>

  



            <div class="card">
                <img src="images/animal1.jpg" alt="animal 2">
                <div class="card-info">
                    <h2>Chicken Farm 2</h2>
                </div>
                <div class="card-popup">
                    <br>
                    <br>
                    <br>
                <p>45 Red Bell Pepper Plants</p>
                    <p>3 Red Bell Peppers</p>
                    <p>4.0 Soil PH Level</p>
                    <p>70% Oxygen</p>
                    <p>10% Phosphorus</p>
                    <p>10% Nitrogen<p>
                    <button class="edit-btn" id="edit-btn">Edit</button>
                    <button class="delete-farm-btn">- Delete Farm</button>

                    <div id="edit-modal" class="modal">
                        <div class="modal-content">
                            <span class="close">&times;</span>
                            <h2>Edit Farm Details</h2>
                            <br>
                            <form>
                                <label for="phosphorus">No. of Carrots Planted:</label>
                                <input type="text" id="planted" name="planted">
                                <br>
                                <label for="phosphorus">No. of Carrots Produced:</label>
                                <input type="text" id="produced" name="produced">
                                <br>
                                <label for="phosphorus">Soil PH Level:</label>
                                <input type="text" id="PH" name="PH">
                                <br>
                                <label for="phosphorus">Phosphorus:</label>
                                <input type="text" id="phosphorus" name="phosphorus">
                                <br>
                                <label for="nitrogen">Nitrogen:</label>
                                <input type="text" id="nitrogen" name="nitrogen">
                                <br>
                                <label for="oxygen">Oxygen:</label>
                                <input type="text" id="oxygen" name="oxygen">
                                <br>
                                <input class="sub1mit" type="submit" value="Submit">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            

            <div class="card">
                <img src="images/animal1.jpg" alt="animal 3">
                <div class="card-info">
                    <h2>Chicken Farm 3</h2>
                   
                <div class="card-popup">
                <br>
                    <br>
                    <br>
                    <p>45 Lettuce Plants</p>
                    <p>35 Lettuce Heads</p>
                    <p>4.0 Soil PH Level</p>
                    <p>70% Oxygen</p>
                    <p>10% Phosphorus</p>
                    <p>10% Nitrogen<p>
                    <button class="edit-btn">Edit</button>
                    <button class="delete-farm-btn">- Delete Farm</button>
                </div>
            </div>

            
        </div>

	</div>
            





<script>

// Get the modal
var modal = document.getElementById("edit-modal");

// Get the button that opens the modal
var btn = document.getElementById("edit-btn");

// Add an event listener to the button
btn.addEventListener("click", function() {
  // Show the modal when the button is clicked
  modal.style.display = "block";
});

// Add an event listener to close the modal when clicking outside of it
window.addEventListener("click", function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
});


</script>
</section>
    
</body>
</html>
