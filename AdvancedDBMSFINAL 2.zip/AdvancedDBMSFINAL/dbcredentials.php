<?php
// Define database connection parameters
$hostname = "localhost"; // replace with your hostname
$username = "root"; // replace with your username
$password = ""; // replace with your password
$dbname = "firebase_final"; // replace with your database name


?>