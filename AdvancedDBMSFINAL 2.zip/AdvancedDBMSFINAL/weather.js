const api_key = 'a5d9f9a15b330454724e42ea8bcc7309';
const city = 'YOUR_CITY';
const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${api_key}&units=metric`;

fetch(url)
  .then(response => response.json())
  .then(data => {
    const temperature = Math.round(data.main.temp);
    const description = data.weather[0].description;
    const icon = `http://openweathermap.org/img/wn/${data.weather[0].icon}.png`;
    
    document.getElementById('temperature').innerHTML = `${temperature}°C`;
    document.getElementById('description').innerHTML = description;
    document.getElementById('icon').innerHTML = `<img src="${icon}" alt="${description}">`;
  })
  .catch(error => console.log(error));
