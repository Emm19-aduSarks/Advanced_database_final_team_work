<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require "dbcredentials.php";

// Create connection
$conn = mysqli_connect($hostname, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $barcode = $_POST["Barcode"]; 
    $productName = $_POST["productName"];
    $productType = $_POST["productType"];    
    $manufacturer = $_POST["manufacturer"];
    $quantity_kg = $_POST["qty"];    
    $date_Of_Manufacture = $_POST["dom"];
    $expiration_Date = $_POST["expire"];
    $description = $_POST["desc"];    

    // Prepare an SQL statement
    $sql = "INSERT INTO FarmSales(Barcode, ProductName, ProductType, Manufacturer, Quantity, DateOfManufature, ExpirationDate, Description)
    VALUES ('$barcode','$productName','$productType','$manufacturer','$quantity_kg','$date_Of_Manufacture','$expiration_Date','$description')";


    // Execute the SQL statement
    if (mysqli_query($conn, $sql)) {
      echo "New record created successfully";
    } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
  }
  
  // Close the database connection
  mysqli_close($conn);
?>
