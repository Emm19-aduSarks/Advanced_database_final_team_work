<?php

require "dbcredentials.php";

// Create connection
$conn = mysqli_connect($localhost, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Select data from table
$sql = "SELECT * FROM FarmSales";
$result = mysqli_query($conn, $sql);
$farmsales = mysqli_fetch_all($result, MYSQLI_ASSOC);
//var_dump($crops);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Akoma Farms Dashboard</title>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link rel="stylesheet" href="dashboard.css">
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>

</head>

<body>
   <nav>
       <div class="logo-name">
            <div class="logo-image">
                <img src="images/logomain.png" alt="">
            </div>
            <span class="logo_name">Akoma Farms</span>
        </div>
        <div class="menu-items">
        <ul class="nav-links">
            <li><a href="dashboard.php">
                <i class="uil uil-estate"></i>
                <span class="link-name">Dashboard</span>
            </a></li>
            <li><a href="cropfarms.php">
                <i class="uil uil-pagelines"></i>
                <span class="link-name">Crop Farms</span>
            </a></li>
            <li><a href="customers.php">
            <i class="uil uil-user-square"></i>
                <span class="link-name">Customers</span>
            </a></li>
            <li><a href="cattle_farms.php">
                <i class="uil uil-bug"></i>
                <span class="link-name">Cattle Farms</span>
            </a></li>
            <li><a href="poultry_farms.php">
            <i class="uil uil-twitter"></i>
                <span class="link-name">Poultry Farms</span>
            </a></li>
            <li><a href="employees.php">
            <i class="uil uil-user-circle"></i>
                <span class="link-name">Employees</span>
            </a></li>
            <li><a href="product.php">
                <i class="uil uil-shopping-bag"></i>
                <span class="link-name">Sales</span>
            </a></li>
            </ul>


            <ul class="logout-mode">
                <li><a href="index.php">
                <i class="uil uil-signout"></i>
                <span class="link-name">Logout</span>
                <a></li>




                <li class="mode">
                    <a href="#">
                <a>

                <div class="mode-toggle"></div>
                <span class="switch"></span>
                </li>
            </ul>
        </div>
   </nav>

   <section class="dashboard">
       <div class="top">
       <button class="add-product-btn" id="add-product-btn">+Add Product</button>
       <div id="edit-modal" class="modal">
                        <div class="modal-content">
                            <span class="close">&times;</span>
                        
                            <br>
                            <form method="post" action="product_insert.php">
                            <br>
                                <label for="oxygen">Barcode:</label>
                                <input type="text" id="Barcode" name="Barcode">
                                <br>
                                <label for="phosphorus">Product Name:</label>
                                <input type="text" id="productName" name="productName">
                                <br>
                                <label for="phosphorus">Product Type:</label>
                                <input type="text" id="productType" name="productType">
                                <br>
                                <label for="phosphorus">Manufacturer:</label>
                                <input type="text" id="manufacturer" name="manufacturer">
                                <br>
                                <label for="phosphorus">Quantity(kg):</label>
                                <input type="text" id="qty" name="qty">
                                <br>
                                <label for="phosphorus">Date Of Manufature:</label>
                                <input type="text" id="dom" name="dom">
                                <br>
                                <label for="phosphorus">Expiration Date	:</label>
                                <input type="text" id="expire" name="expire">
                                <br>
                                <label for="phosphorus">Description:</label>
                                <input type="text" id="desc" name="desc">
                                <br>
                                <input class="sub1mit" type="submit" value="Submit">
                            </form>
                        </div>
                    </div>


           <div class="search-box">
               <i class="uil uil-search"></i>
               <input type="text" placeholder="Search Here...">
            </div>

            <img src="images/user.png">
        </div>

  

    <div class="activity">
		<div class="title">
			<i class="uil uil-user-check"></i>                
			<span class="text">Employee Details</span>
		</div>
		<div class="activity-data">
			<table>
				<thead>
					<tr>
                    <th>Barcode	</th>
                    <th>Product Name	</th>
                    <th>Product Type	</th>
                    <th>Manufacturer</th>	
                    <th>Quantity(kg)</th>	
                    <th>Date Of Manufature</th>	
                    <th>Expiration Date</th>	
                    <th>Description	</th>
					</tr>
				</thead>
				<tbody>
                <?php
                foreach($farmsales as $farmsale):
                ?>
					<tr>
						<td><?php echo $farmsale["Barcode"];?></td>
						<td><?php echo $farmsale["ProductName"];?></td>
						<td><?php echo $farmsale["ProductType"];?></td>
						<td><?php echo $farmsale["Manufacturer"];?></td>
                        <td><?php echo $farmsale["Quantity"];?></td>
						<td><?php echo $farmsale["DateOfManufature"];?></td>
						<td><?php echo $farmsale["ExpirationDate"];?></td>
						<td><?php echo $farmsale["Description"];?></td>
					</tr>
                <?php
                  endforeach;
                ?>
                   
			
				</tbody>
			</table>
		</div>
	</div>
            


        </div>
    </div>
</section>

<script>
    // Get the modal
var modal = document.getElementById("edit-modal");

// Get the button that opens the modal
var btn = document.getElementById("add-product-btn");

// Add an event listener to the button
btn.addEventListener("click", function() {
  // Show the modal when the button is clicked
  modal.style.display = "block";
});

// Add an event listener to close the modal when clicking outside of it
window.addEventListener("click", function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
});

</script>
    
</body>
</html>
