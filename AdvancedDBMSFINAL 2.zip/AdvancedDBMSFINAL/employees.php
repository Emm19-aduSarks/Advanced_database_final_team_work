<?php

require "dbcredentials.php";

// Create connection
$conn = mysqli_connect($localhost, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Select data from table
$sql = "SELECT * FROM StaffMember";
$result = mysqli_query($conn, $sql);
$employees = mysqli_fetch_all($result, MYSQLI_ASSOC);
//var_dump($crops);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Akoma Farms Dashboard</title>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link rel="stylesheet" href="dashboard.css">
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>

</head>

<body>
   <nav>
       <div class="logo-name">
            <div class="logo-image">
                <img src="images/logomain.png" alt="">
            </div>
            <span class="logo_name">Akoma Farms</span>
        </div>
        <div class="menu-items">
        <ul class="nav-links">
            <li><a href="dashboard.php">
                <i class="uil uil-estate"></i>
                <span class="link-name">Dashboard</span>
            </a></li>
            <li><a href="cropfarms.php">
                <i class="uil uil-pagelines"></i>
                <span class="link-name">Crop Farms</span>
            </a></li>
            <li><a href="customers.php">
            <i class="uil uil-user-square"></i>
                <span class="link-name">Customers</span>
            </a></li>
            <li><a href="cattle_farms.php">
                <i class="uil uil-bug"></i>
                <span class="link-name">Cattle Farms</span>
            </a></li>
            <li><a href="poultry_farms.php">
            <i class="uil uil-twitter"></i>
                <span class="link-name">Poultry Farms</span>
            </a></li>
            <li><a href="employees.php">
            <i class="uil uil-user-circle"></i>
                <span class="link-name">Employees</span>
            </a></li>
            <li><a href="product.php">
                <i class="uil uil-shopping-bag"></i>
                <span class="link-name">Sales</span>
            </a></li>
            </ul>

            <ul class="logout-mode">
                <li><a href="index.php">
                <i class="uil uil-signout"></i>
                <span class="link-name">Logout</span>
                <a></li>




                <li class="mode">
                    <a href="#">
                <a>

                <div class="mode-toggle"></div>
                <span class="switch"></span>
                </li>
            </ul>
        </div>
   </nav>

   <section class="dashboard">
       <div class="top">
       <button class="add-employee-btn" id="add-employee-btn">+Add Employee</button>
       <div id="edit-modal" class="modal">
                        <div class="modal-content">
                            <span class="close">&times;</span>
                        
                            <br>
                            <form method="post" action="employee_insert.php">
                            <br>
                                <label for="oxygen"> Staff Member ID:</label>
                                <input type="text" id="staffMemberID" name="staffMemberID">
                                <br>
                                <label for="oxygen">First Name:</label>
                                <input type="text" id="fname" name="fname">
                                <br>
                                <label for="phosphorus">Last Name:</label>
                                <input type="text" id="lname" name="lname">
                                <br>
                                <label for="phosphorus">Address:</label>
                                <input type="text" id="adress" name="adress">
                                <br>
                                <label for="phosphorus">Phone Number:</label>
                                <input type="text" id="phone" name="phone">
                                <br>
                                <label for="phosphorus">Gender:</label>
                                <input type="text" id="gender" name="gender">
                                <br>
                                <label for="phosphorus">Email:</label>
                                <input type="text" id="email" name="email">
                                <br>
                                <label for="phosphorus">Birth Date:</label>
                                <input type="text" id="farm_ass" name="farm_ass">
                                
                                <input class="sub1mit" type="submit" value="Submit">
                            </form>
                        </div>
                    </div>


           <div class="search-box">
               <i class="uil uil-search"></i>
               <input type="text" placeholder="Search Here...">
            </div>

            <img src="images/user.png">
        </div>

  

    <div class="activity">
		<div class="title">
			<i class="uil uil-user-check"></i>                
			<span class="text">Employee Details</span>
		</div>
		<div class="activity-data">
			<table>
				<thead>
					<tr>
                        <th>Staff ID</th>
						<th>First Name</th>
						<th>Last Name</th>
						<th>Address</th>
						<th>Phone Number</th>
                        <th>Gender</th>
                        <th>Email</th>
                        <th>Birth Date</th>
					</tr>
				</thead>
				<tbody>
                <?php
                 foreach($employees  as $employee):
                ?>
					<tr>
                        <td><?php echo $employee["StaffMemberID"];?></td>
						<td><?php echo $employee["FirstName"];?></td>
						<td><?php echo $employee["LastName"];?></td>
						<td><?php echo $employee["Address"];?></td>
						<td><?php echo $employee["Phone"];?></td>
                        <td><?php echo $employee["Gender"];?></td>
						<td><?php echo $employee["Email"];?></td>
						<td><?php echo $employee["BirthDate"];?></td>
						<td><?php echo $employee["First_Name"];?></td>
					</tr>
                <?php
                 endforeach;
                ?>
                    
				</tbody>
			</table>
		</div>
	</div>
            


        </div>
    </div>
</section>

<script>
    // Get the modal
var modal = document.getElementById("edit-modal");

// Get the button that opens the modal
var btn = document.getElementById("add-employee-btn");

// Add an event listener to the button
btn.addEventListener("click", function() {
  // Show the modal when the button is clicked
  modal.style.display = "block";
});

// Add an event listener to close the modal when clicking outside of it
window.addEventListener("click", function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
});

</script>
    
</body>
</html>
