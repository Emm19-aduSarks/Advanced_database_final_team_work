<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


require "dbcredentials.php";

// Create connection
$conn = mysqli_connect($hostname, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Get the form data
  $cropType = $_POST["ct"];
  $soilType= $_POST["st"];
  $fertilizerType = $_POST["ft"];
  $plantDate = $_POST["pd"];
  $harvestDate = $_POST["hd"];
  $yield = $_POST["yie"];
  $cropfarmIdvar = $_POST["cropfarmID"];

//   echo $cropfarmIdvar;

  // Prepare the SQL statement
  $sql = "UPDATE CropFarm
  SET CropType = '$cropType', SoilType = '$soilType', FertilizerType = '$fertilizerType', PlantDate = '$plantDate', HarvestDate = '$harvestDate', Yield = '$yield'
  WHERE CropFarmID = $cropfarmIdvar";



  // Execute the SQL statement
  if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
    header("Location: cropfarms.php");
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
}

// Close the database connection
$conn->close();
?>