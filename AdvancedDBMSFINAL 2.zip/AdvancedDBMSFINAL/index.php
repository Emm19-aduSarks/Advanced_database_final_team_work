<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login Page</title>
  <link rel="stylesheet" href="index.css">
</head>
<body>
  <div class="login-box">
    <img src="images/logomain.png" class="logoligi">
    <h2>Login</h2>
    <form  action="dashboard.php">
      <div class="user-box">
        <input type="text" name="name" required="">
        <label>Name</label>
      </div>
      <div class="user-box">
        <input type="email" name="email" required="">
        <label>Email</label>
      </div>
      <div class="user-box">
        <input type="password" name="password" required="">
        <label>Password</label>
      </div>
      <a href="#">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <button class="SUB" type="submit">Submit</button>
      </a>
    </form>
  </div>
</body>
</html>
