<?php

require "dbcredentials.php";

// Create connection
$conn = mysqli_connect($localhost, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Select data from table
$sql = "SELECT * FROM CropFarm";
$result = mysqli_query($conn, $sql);
$crops = mysqli_fetch_all($result, MYSQLI_ASSOC);
//var_dump($crops);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Akoma Farms Dashboard</title>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link rel="stylesheet" href="dashboard.css">
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>

</head>

<body>
   <nav>
       <div class="logo-name">
            <div class="logo-image">
                <img src="images/logomain.png" alt="">
            </div>
            <span class="logo_name">Akoma Farms</span>
        </div>
        <div class="menu-items">
            <ul class="nav-links">
            <li><a href="dashboard.php">
                <i class="uil uil-estate"></i>
                <span class="link-name">Dashboard</span>
            </a></li>
            <li><a href="cropfarms.php">
                <i class="uil uil-pagelines"></i>
                <span class="link-name">Crop Farms</span>
            </a></li>

            <li><a href="customers.php">
            <i class="uil uil-user-square"></i>
                <span class="link-name">Customers</span>
            </a></li>
         
            <li><a href="cattle_farms.php">
                <i class="uil uil-bug"></i>
                <span class="link-name">Cattle Farms</span>
            </a></li>

            <li><a href="poultry_farms.php">
            <i class="uil uil-twitter"></i>
                <span class="link-name">Poultry Farms</span>
            </a></li>

            <li><a href="employees.php">
            <i class="uil uil-user-circle"></i>
                <span class="link-name">Employees</span>
            </a></li>
            <li><a href="product.php">
                <i class="uil uil-shopping-bag"></i>
                <span class="link-name">Sales</span>
            </a></li>
            </ul>

            <ul class="logout-mode">
                <li><a href="index.php">
                <i class="uil uil-signout"></i>
                <span class="link-name">Logout</span>
                <a></li>




                <li class="mode">
                    <a href="#">
                <a>

                <div class="mode-toggle"></div>
                <span class="switch"></span>
                </li>
            </ul>
        </div>
   </nav>

   

   <section class="dashboard">
       <div class="top">
            
           <!-- <button class="add-farm-btn" id="add-farm-btn">+Add Farm</button> -->
           

           <div class="search-box">
               <i class="uil uil-search"></i>
               <input type="text" placeholder="Search Here...">
            </div>

            <img src="images/user.png">
        </div>

        <div id="edit-modal2" class="modal">
                        <div class="modal-content">
                            <span class="close">&times;</span>
                            <h2>Edit Farm Details</h2>
                            <br>
                            <form>
                                <label for="croptype">Crop Type:</label>
                                <input type="text" id="planted" name="planted">
                                <br>
                        
                                <label for="soiltype">Soil Type:</label>
                                <input type="text" id="PH" name="PH">
                                <br>
                                <label for="ft">Fertilizer Type:</label>
                                <input type="text" id="phosphorus" name="phosphorus">
                              
                                <br>
                                <label for="pd"> Plant Date:</label>
                                <input type="text" id="phosphorus" name="phosphorus">
                             
                                <br>
                                <label for="hd">Harvest Date:</label>
                                <input type="text" id="phosphorus" name="phosphorus">
                              
                                <label for="yield">Yield:</label>
                                <input type="text" id="phosphorus" name="phosphorus">
                                <br>
                                <input class="sub1mit" type="submit" value="Submit">
                            </form>
                        </div>
            </div>

       

    <div class="crops" style="float:left">
        <br>
        <br>
        <br>
        <?php
         foreach($crops as $crop):
        ?>
            <div class="card">
                <img src="images/crop.png" alt="Fruit 1">
                <div class="card-info">
                    <h2><?php echo $crop["CropType"];?> Farm</h2>
                    
                </div>

                <div class="card-popup">

                    <br>
                    <br>
                    <br>
                        <p><?php echo $crop["CropType"];?> Plants</p>
                        <p><?php echo $crop["SoilType"];?></p>
                        <p><?php echo $crop["FertilizerType"];?></p>
                        <p>Plant Date: <?php echo $crop["PlantDate"];?></p>
                        <p>Harvest Date: <?php echo $crop["HarvestDate"];?></p>
                        <p><?php echo $crop["Yield"];?>kg Harvested</p>
                    <button class="edit-btn" id = "edit-btn" data-crop_farm_ID="<?php echo $crop["CropFarmID"]?>" onclick="getCropFarmID(this)">Edit</button>
                    <button class="delete-farm-btn">- Delete Farm</button>
                </div>
            </div>
            <?php
            endforeach;
            ?>
            <div id="edit-modal" class="modal">
                        <div class="modal-content">
                            <span class="close">&times;</span>
                            <h2>Edit Farm Details</h2>
                            <br>
                            <form method="POST" action="cropedit.php">
                            <br>
                                <label for="oxygen">Crop Type:</label>
                                <input type="text" id="ct" name="ct">
                                <br>
                                <label for="phosphorus">Soil Type:</label>
                                <input type="text" id="st" name="st">
                                <br>
                                <label for="phosphorus">Fertilizer Type:</label>
                                <input type="text" id="ft" name="ft">
                                <br>
                                <label for="phosphorus">Plant Date:</label>
                                <input type="text" id="pd" name="pd">
                                <br>
                                <label for="phosphorus">Harvest Date:</label>
                                <input type="text" id="hd" name="hd">
                                <br>
                                <label for="nitrogen">Yield:</label>
                                <input type="text" id="yie" name="yie">
                                <input type="hidden" name="cropfarmID" id="cropfarmID"> 
                              
                                <input class="sub1mit" type="submit" name = "submit" value="Submit">
                            </form>
                        </div>
                    </div>      
        </div>

	</div>
            





<script>
// Get the modal
var modal = document.getElementById("edit-modal");
var modal2 = document.getElementById("edit-modal2");

// Get the button that opens the modal
const btn = document.querySelectorAll('.edit-btn');
var btn2 = document.getElementById("add-farm-btn");

btn.forEach(button => {
    button.addEventListener('click',() =>{
        modal.style.display = "block";
    });
});

// Add an event listener to the button
btn2.addEventListener("click", function() {
  // Show the modal when the button is clicked
  modal2.style.display = "block";
});

// Add an event listener to close the modal when clicking outside of it
window.addEventListener("click", function(event) {
  if (event.target == modal2) {
    modal2.style.display = "none";
  }
});

function getCropFarmID(button){
    var cropFarmId = button.getAttribute("data-crop_farm_ID");

    //select hidden input
    const h_input = document.getElementById("cropfarmID");
    h_input.value = cropFarmId;
    //alert(cropFarmId);

}
</script>

    
</body>
</html>
