<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require "dbcredentials.php";

// Create connection
$conn = mysqli_connect($hostname, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $FirstName = $_POST["fname"]; 
    $LastName= $_POST["lname"];	
    $email= $_POST["email"];
    $phone= $_POST["phone"];	
    $address= $_POST["adress"];

    // Prepare an SQL statement
    $sql = "INSERT INTO customer (First_Name, Last_Name, email, phone, address) VALUES ('$FirstName','$LastName','$email','$phone','$address')";
  
    // Execute the SQL statement
    if (mysqli_query($conn, $sql)) {
      echo "New record created successfully";
    } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
  }
  
  // Close the database connection
  mysqli_close($conn);
  ?>


?>